//
//  DataToJSPresenter.h
//  RNHybirdiOS
//
//  Created by jph on 27/06/2018.
//  Copyright © 2018 devio. All rights reserved.
//

#import <React/RCTBridgeModule.h>


@interface JSBridgeModule : NSObject <RCTBridgeModule>

@end
