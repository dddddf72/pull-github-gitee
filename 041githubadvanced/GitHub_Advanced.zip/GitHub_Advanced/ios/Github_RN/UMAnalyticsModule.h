#import <Foundation/Foundation.h>
#import <React/RCTBridgeModule.h>
@interface UMAnalyticsModule : NSObject  <RCTBridgeModule>

@end
