//
//  Constants.h
//  Github_RN
//
//  Created by jph on 2018/11/24.
//  Copyright © 2018 Facebook. All rights reserved.
//

/******Umeng相关配置********/
#define UM_AppKey @"57fb2111e0f55aaf2d003257"
#define UM_ChannelId @"App Store"
#define AppKey_WB @"3114976530"
#define AppSecret_WB @"40a599d4fa35b733e3562f19241eabe9"
#define AppKey_WX @"wx3b88e890abe41fce"
#define AppSecret_WX @"0dde0a5a5efeb080b086f3f969f386bc"
#define AppKey_QQ @"1105745872"
#define AppSecret_QQ @"KXOXABjlHrqrJD3z"
